send me to 'writeme3.txt'.

